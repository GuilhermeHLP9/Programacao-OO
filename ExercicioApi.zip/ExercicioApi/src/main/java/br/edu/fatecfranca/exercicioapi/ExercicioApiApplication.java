package br.edu.fatecfranca.exercicioapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExercicioApiApplication.class, args);
    }

}
